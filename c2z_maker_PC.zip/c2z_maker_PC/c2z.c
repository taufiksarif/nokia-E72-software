// version 20080511 . Just 1 file with 3 lines
#include <stdio.h>
#include <string.h>

main(int argc, char *argv[])
{
FILE *ap, *ap_bin_in, *ap_bin_out, *ap_out_rmp;
unsigned char c0,c1,c2,c3;
unsigned old_code_c0,old_code_c1,old_code_c2,old_code_c3;
unsigned old_jmp_c0,old_jmp_c1,old_jmp_c2,old_jmp_c3;
unsigned new_jmp_c0,new_jmp_c1,new_jmp_c2,new_jmp_c3;
unsigned old_RFormat_Open[400];
int i, asc, end=0, step=0, bytes_written=0;
char cad[4000], cad2[4000];
long where_RFile_Open=0, code_addr=0;
long where_RFormat_Open=0, where_RFormat_Open_last4;
long low_bits, high_bits, old_where_jmp, new_where_jmp;

ap=fopen("EFSrv.dll","rb");
if(ap==NULL)
    {
    printf("Can not find EFSrv.dll");
    exit(1);
    }
fseek(ap,0x10,SEEK_SET);
c0=getc(ap);
c1=getc(ap);
c2=getc(ap);
c3=getc(ap);
code_addr=c3*256*256*256+c2*256*256+c1*256+c0;
printf("code_addr=%0.8X\n", code_addr);

while(!feof(ap) && !where_RFile_Open) // F8222810/F82404F4 1674    1st entry
{
c0=getc(ap);
c1=getc(ap);
if(c0==0x10 && c1==0xB5)
    {
    c0=getc(ap);
    c1=getc(ap);
    if(c0==0x86 && c1==0xB0)
        {
        c0=getc(ap);
        c1=getc(ap);
        if(c0==0x01 && c1==0x92)
            {
            c0=getc(ap);
            c1=getc(ap);
            if(c0==0x07 && c1==0x22)
                {
                c0=getc(ap);
                c1=getc(ap);
                where_RFile_Open=ftell(ap)-10;
                printf("RFile::Open=%0.8X\n", code_addr-0x78+where_RFile_Open);
                for(i=0;i<14;i++)   // search BL      call_RSubSessionBase__DoCreateSubSession
                    {
                    c0=getc(ap);
                    c1=getc(ap);
                    if(c0==0x02 && c1==0x94)    // STR     R4, [SP,#8]
                        {
                        c0=getc(ap);old_jmp_c0=c0;
                        c1=getc(ap);old_jmp_c1=c1;
                        c2=getc(ap);old_jmp_c2=c2;
                        c3=getc(ap);old_jmp_c3=c3;
                        printf("jmp to=%0.2X %0.2X %0.2X %0.2X\n", c0, c1, c2, c3);
                        high_bits = (c1*256+c0) & 0x000007FF;
                        low_bits = ((c3*256+c2) & 0x000007FF)*2;
                        printf("low_bits=%0.8X\n", low_bits);
                        printf("high_bits=%0.8X\n", high_bits);
                        old_where_jmp=(high_bits*256*16+low_bits)*1+2;
                        printf("old_where_jmp=%0.8X\n", old_where_jmp);
                        printf("j_Session=%0.8X\n", code_addr-0x78+ftell(ap)-4+old_where_jmp+2+1);
                        old_where_jmp=code_addr-0x78+ftell(ap)-4+old_where_jmp+2+1;
                        printf("old_where_jmp=%0.8X\n", old_where_jmp);
                        }
                    }
                }
            fseek(ap,where_RFile_Open, SEEK_SET);
            old_code_c0=getc(ap);
            old_code_c1=getc(ap);
            old_code_c2=getc(ap);
            old_code_c3=getc(ap);
            }
        }
    }
}
fclose(ap);

ap=fopen("EFSrv.dll","rb");
while(!feof(ap) && !where_RFormat_Open) // F82252A0/F8242F84 4104
{
c0=getc(ap);
c1=getc(ap);
if(c0==0xF0 && c1==0xB5)
    {
    c0=getc(ap);
    c1=getc(ap);
    if(c0==0x04 && c1==0x00)
        {
        c0=getc(ap);
        c1=getc(ap);
        if(c0==0x16 && c1==0x00)
            {
            c0=getc(ap);
            c1=getc(ap);
            if(c0==0x0D && c1==0x00)
                {
                c0=getc(ap);
                c1=getc(ap);
                where_RFormat_Open=ftell(ap)-10;
                fseek(ap,where_RFormat_Open, SEEK_SET);
                new_where_jmp=code_addr-0x78+where_RFormat_Open;
                printf("RFormat::Open=%0.8X\n", new_where_jmp);
                for(i=0;i<0x4*80;i++)
                    {
                    c0=getc(ap);
                    old_RFormat_Open[i]=c0;
                    }
                }
            }
        }
    }
}

fclose(ap);
printf("where_RFile_Open=%0.4X\n", where_RFile_Open);
printf("where_RFormat_Open=%0.4X\n", where_RFormat_Open);

printf("driveCbeforeZ\n");
printf("just4U\n");

// as the new code goes through 2 segments, need to map the second as well
// doesn't change anything; only maps
where_RFormat_Open_last4=where_RFormat_Open+0x4*80-4;
sprintf(cad,"rel:sys\\bin\\EFSrv.dll:%0.8X:%0.2X%0.2X%0.2X%0.2X:%0.2X%0.2X%0.2X%0.2X", where_RFormat_Open_last4,
                        old_RFormat_Open[0x4*80-4],old_RFormat_Open[0x4*80-3],old_RFormat_Open[0x4*80-2],old_RFormat_Open[0x4*80-1],
                        old_RFormat_Open[0x4*80-4],old_RFormat_Open[0x4*80-3],old_RFormat_Open[0x4*80-2],old_RFormat_Open[0x4*80-1]
      );
// printf(cad);
ap_out_rmp=fopen("c2z.rmp","wt");
fprintf(ap_out_rmp,"; c2z-20080511\n");
fprintf(ap_out_rmp,"; maps Z: to C: for some files\n");

fprintf(ap_out_rmp,"%s\n",cad);

printf("real:%0.8X - %0.8X\n",where_RFormat_Open+code_addr-0x70, where_RFormat_Open+code_addr-0x70+0x4*80);

sprintf(cad,"rel:sys\\bin\\EFSrv.dll:%0.8X:",where_RFormat_Open);
for(i=0;i<0x4*80-3*4;i++)
    {
    sprintf(cad2, "%0.2X",old_RFormat_Open[i]);      strcat(cad,cad2);
    }
sprintf(cad2,":");   strcat(cad,cad2);

ap_bin_in=fopen("patch.bin","rb");
ap_bin_out=fopen("patcho.bin","wb");
step=0;
bytes_written=0;
while(!feof(ap_bin_in))
    {
    c0=getc(ap_bin_in);
    c1=getc(ap_bin_in);
    c2=getc(ap_bin_in);
    c3=getc(ap_bin_in);
    bytes_written+=4;
    if(c0==0xA9)
        {
        // printf("\n 1\n");
        c0=old_where_jmp & 0xFF;
        sprintf(cad2,"%0.2X%0.2X%0.2X%0.2X",c0,0x60,0xA0,0xE3);     strcat(cad,cad2);
        putc(c0,ap_bin_out);    putc(0x60,ap_bin_out);    putc(0xA0,ap_bin_out);    putc(0xE3,ap_bin_out);
        step=2;
        }
    else if(step==2)
        {
        // printf("\n 2\n");
        c0=(old_where_jmp>>8) & 0xFF;
        // printf("old_where_jmp=%0.8X %0.8X\n", old_where_jmp, c0);
        sprintf(cad2, "%0.2X%0.2X%0.2X%0.2X",c0,0x6C,0x86,0xE2);      strcat(cad,cad2);
        putc(c0,ap_bin_out);    putc(0x6C,ap_bin_out);    putc(0x86,ap_bin_out);    putc(0xE2,ap_bin_out);
        step++;
        }
    else if(step==3)
        {
        // printf("\n 3\n");
        c0=(old_where_jmp>>16) & 0xFF;
        sprintf(cad2, "%0.2X%0.2X%0.2X%0.2X",c0,0x68,0x86,0xE2);     strcat(cad,cad2);
        putc(c0,ap_bin_out);    putc(0x68,ap_bin_out);    putc(0x86,ap_bin_out);    putc(0xE2,ap_bin_out);
        step++;
        }
    else if(step==4)
        {
        // printf("\n 4\n");
        c0=(old_where_jmp>>24) & 0xFF;
        sprintf(cad2, "%0.2X%0.2X%0.2X%0.2X",c0,0x64,0x86,0xE2);     strcat(cad,cad2);
        putc(c0,ap_bin_out);    putc(0x64,ap_bin_out);    putc(0x86,ap_bin_out);    putc(0xE2,ap_bin_out);
        // printf(" 4\n");
        step=0;
        }
    else
        if(!feof(ap_bin_in))
            {
            sprintf(cad2, "%0.2X%0.2X%0.2X%0.2X",c0,c1,c2,c3);   strcat(cad,cad2);
            putc(c0,ap_bin_out);    putc(c1,ap_bin_out);    putc(c2,ap_bin_out);    putc(c3,ap_bin_out);
            }
    }
for(i=bytes_written;i<=0x4*80-3*4;i+=4)
    {
    sprintf(cad2, "%0.8X",0x1234567);      strcat(cad,cad2);
    }

// printf(cad);
fprintf(ap_out_rmp,"%s\n",cad);

printf("\n");

sprintf(cad,"rel:sys\\bin\\EFSrv.dll:%0.8X:%0.2X%0.2X%0.2X%0.2X", where_RFile_Open, old_code_c0,old_code_c1,old_code_c2,old_code_c3 );
sprintf(cad2, "019207221C0005921E2201AB");  strcat(cad,cad2);
sprintf(cad2,":");     strcat(cad,cad2);
sprintf(cad2,"%0.2X%0.2X%0.2X%0.2X", 0x10,0xB5,0x01,0x4C );    strcat(cad,cad2);
sprintf(cad2,"%0.2X%0.2X%0.2X%0.2X", 0xA0,0x47,0x10,0xBD );    strcat(cad,cad2);
sprintf(cad2,"%0.2X%0.2X%0.2X%0.2X", (new_where_jmp>>0)&0xFF,(new_where_jmp>>8)&0xFF,(new_where_jmp>>16)&0xFF,(new_where_jmp>>24)&0xFF );  strcat(cad,cad2);
sprintf(cad2,"%0.2X%0.2X%0.2X%0.2X", (new_where_jmp>>0)&0xFF,(new_where_jmp>>8)&0xFF,(new_where_jmp>>16)&0xFF,(new_where_jmp>>24)&0xFF );  strcat(cad,cad2);
// printf(cad);
fprintf(ap_out_rmp,"%s\n",cad);

fclose(ap_out_rmp);

return 1;
}