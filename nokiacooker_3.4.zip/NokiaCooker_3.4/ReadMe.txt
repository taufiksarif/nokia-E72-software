﻿
NokiaCooker 3.4
http://www.symbian-toys.com/NokiaCooker.aspx



*** Informations for Developers about Plugins ***

When NokiaCooker launches your application it will pass the 4 command-line parameters below:
1) the file currently selected in the window on the right side
2) the path where the fw files have been extracted (eg: c:\nokiacooker\files\n8fw_extracted\)
3) firmware filename (eg: RM-596_011.012_U01.01_79.92_prd.uda.fpsx)
4) firmware type (UDA, ROFS, CORE, UNKNOWN)

How to read the arguments depends on the programming language you're using:
- for Delphi you should use ParamStr() ParamCount() 
- for C# you can find the source code of a skeleton Plugin inside "TestPlugins - SourceCode.zip"



*** History ***

3.4
- New: NokiaCooker will automatically download and install new updates
- Fixed: "Can't detect partition data" was shown, when opening some core fw files (eg. N95, N96)
- Improved: NaviFirm+ v2.0
- Improved: you can disable the backup creation by setting the "MakeBackup" value to "False" in the .config file
- Improved: partition detection (added partvers 0x0100000)

3.3
- New: can be associated to .vpl and .fpsx extensions. Just double-click on a fw file, NokiaCooker will be launched and unpack the selected fw file
- Improved: general exception handling. Some exceptions were not caught correctly, causing NokiaCooker to unexpectedly close without showing any error message.
- Improved: minor improvements

3.2
- New: Partition Manager. It is now possible to repartition the fw and choose the size of ROFS1, ROFS2, ROFS3, UDA. You can even transfer the free ROFS space to the UDA, in order to increase the total available space on c:\       
       You should not use the Partition Manager on cfw which have been already repartitioned in other ways.
- Improved: the copy option in the log window, copies only the selected text
- Improved: new block (3A) gets parsed for CORE files
- Improved: new header fields (E5, EA) gets parsed for CORE files
- Improved: better Fat detection for UDA files
- Improved: rewritten parsing of .vpl files
- Fixed: when connected to the pc, the Phone Memory was shown as "NOKIACOO~0" or "NCxx"
- Fixed: a wrong clusters computation, could cause a data loss for the 2 last clusters in the UDA, when filled at the top.

3.1
- New: added a new message to the Cookers.
- Improved: the "Expand All / Collapse All" options, will expand and collapse only the currently selected folder.
- Fixed: when sorting list, sometimes empty lines were shown, instead of the files entries.
- Fixed: error message "can not read from the end of the stream" when opening some UDA files (eg. X7)

3.0
- Fixed: when trying to extend the ROFS1 an ArgumentOutOfRangeException was raised for some fw files (eg. N95)

2.9
- Fixed: error message "can not read from the end of the stream" when repacking some UDA files (eg. X7)

2.8
- Fixed: removed message "This version is too much old"

2.7
- Fixed: then error message "key not present in the dictionary" was shown in some circumstances during repack.
- Improved: NaviFirm+ plugin has been updated to the latest version 1.7

2.6 Change-Log:
- Fixed: Extend ROFS1 feature was broken due to the 2.5 changes related to the Unlock ROFS.

2.5 Change-Log:
- Fixed: sometimes the following message was wrongly shown when saving the fw file "Error repacking fw, Block position has changed! Please contact: m.bellino@symbian-toys.com"
- Improved: Unlock ROFS feature has been rewritten to support a larger set of core files.
- Improved: NokiaCooker adds its own signature to the file \resource\versions\customersw.txt

2.4 Change-Log:
- New: I've only added a personal message to Cookers :) It will be shown after the fw has been repacked.

2.3.1 Change-Log:
- Fixed: the final CRC value was still wrong for some fw files.

2.3 Change-Log:
- Fixed: a quick, but important, bug-fix. In the previous version, the changes to the ROFS1 (CORE) were not applied.

2.2 Change-Log:
- New: added new option to extract the ROM. You can find it inside the menu "Advanced > Extract ROM to File..."
- Improved: reports an error when trying to open corrupted firmware files.
- Improved: slightly changes to the fw parsing engine.
- Fixed: the final CRC value was wrong for files < 1Mb
- Fixed: "Can't detect Partition Data" error when opening an unkown image format.

2.1 Change-Log:
- New: you can extend the ROFS1 partition to the maximum size.
- New: added Yellow status for the Estimated Size. 
	.When it is marked in Red, the repack will probably fail and you'll be forced to remove some data.
	.When it is marked in Green the repack will probably complete successfully.
	.When it is marked in Yellow, the size of the current data is near to the limits of the Partition, so you have to try to repack the fw to know exactly if it will be repacked successfully or not.
	.In any case, NokiaCooker will never let you write outside of the Partition Size limits, so it will be always safe to flash the repacked fw.
- Improved: shows a confirm dialog when you attempt to close the fw file and it has not been saved yet.
- Improved: in order to grand a safe repack, 2 different checks are performed when repacking the data to be 100% sure that the new data will not exceed the maximum partition length.
- Improved: toolbars settings (text and icon size) can be customized using the right mouse button.
- Improved: added expand all / collapse all commands in the treeview.
- Improved: avoid TreeView flickering when the directory selected contains a lot of files.
- Improved: computation of the final CRC takes less memory, allowing to process bigger UDA files.
- Improved: better computation of the new blocks needed during repack.
- Improved: ROFS1 partition size detection.
- Fixed: message "NokiaCooker is running as Administrator" was wrongly shown when UAC was disabled.
- Fixed: after removing some data from the ROFS1, the filesize of the repacked fw was still unchanged.
- Fixed: shows an error when trying to repack an unsupported UDA-MMC (BlockType49)
- Fixed: drag&drop was disabled after selecting a recent fw file that didn't exist anymore

2.02 Change-Log:
- Fixed: for some fw, the rebuild corrupts the header informations

2.01 Change-Log:
- Fixed: forgot to remove some debugging code that raises some errors when rebuilding images.

2.0 Change-Log:
- New: it is now possible to cook ROFS1 too
- New: unlock ROFS1 / ROFS2 / ROFS3 feature (aka "ROFS Recalibration")
- New: Estimated Size and Partition Size are available for FAT image too
- New: added the "Explore Files" button in the toolbar
- New: added main icon
- New: added a context menu to both TreeView and Grid
- Improved: performances when viewing folders containing lot of files
- Improved: performances when deleting the temporary files
- Improved: performances when computing the estimated size
- Improved: performances for the treeview control
- Improved: grid component has been replaced with a new one
- Improved: error handling when opening bad fw files
- Improved: computation of the original CRC has been refactored to use less memory
- Improved: added marker (*) to the fw filename to notify fw needs to be saved
- Improved: Header Parsing
- Improved: log window contains more details
- Improved: minor changes in the GUI
- Improved: realtime detection for the changes in the file-system. The GUI will be automatically updated when you add/remove/rename contents directly using Explore.
- Fixed: Detection of the Partition Size
- Fixed: Computation of the Estimated Size
- Fixed: Wrong CRC computation for some UDA files (eg. N95)
- Fixed: Error when repacking an empty ROFS

1.1 Change-Log:
- Fixed: support for large UDA files too (N8 - 16Gb File) but it will takes a lot of time to process them.
- Improved: NaviFirm+ plugin updated to 1.1 version
- Improved: ROFX repack seems to work properly (E71)
- Improved: ROFS repack is more accurate. Supports the attExtra attribute (N8)

1.0 Change-Log:
- New: Shows the maximum ROFS partition size and the ROFS extimated size.
- Improved: NaviFirm plugin updated to 0.9 version
- Improved: the "Allow ROFS Resize" option is not needed anymore and it has been removed.
- Fixed: the "Allow ROFS Resize" option sometimes corrupted the ROFS rebuild process, causing strange issues in the Cooked Fw.

0.9 Change-Log:
- New: File > Recent Files
- Improved: NaviFirm plugin updated to the latest version
- Fixed: The "Advanced > Repack using rofs data: ROFS.ROM" option wasn't working properly when packing a ROFS bigger than original

0.8 Change-Log:
- Fixed: Due to some recent changes the CRC-Fixer routine wasn't working properly anymore.
- Fixed: Removed tooltip from the "add/remove plugins" button.
- Improved: The CRC-Fixer routine will fix the fw CRC to match the one contained in the .vpl file (if the .vpl file exists) otherwise will match the original CRC if the .vpl file doesn't exists.
- Improved: Unpacking Speed.

0.7 Change-Log:
- New: Support for 3rd party Applications/Plugins. You can Drag & Drop any executables to the Plugin's toolbar to add them to NokiaCoooker
- Fixed: for some UDA, the bkupBootRecord wasn't handled properly showing the message "Root Cluster is NOT Supported!"

0.6 Change-Log:
- New: Added a smart CRC-Fixer: There will be no more CRC warnings in Phoenix!
- Improved: Replaced checkbox with button for ROFS resize
- Improved: Sligtly GUI improvements
- Improved: Better performances when showing folders with a lot of files

0.5 Change-Log:
- New: you can now create cooked fw for N8 (UDA/FAT only)
- New: added a checkbox to allow resizing of ROFS/ROFx images.
- Fixed: FAT/UDA editor wasn't working properly.

0.4.3 Change-Log:
- Improved: Log Window can be resized
- Improved: The OBY is created trying to keep the same file order as in the original firmware.
- Fixed: Warnings raised from the RofsBuild.exe command will be shown in the log window and the repack will complete successfully. If the RofsBuild.exe raised an error, the repack will not be completed.

0.4.2 Change-Log:
- Fixed: Some ROFS file were skipped during the Rebuild if the file was in a very long path like:
"C:\Documents and Settings\Root\Desktop\NokiaCooker BETA 0.4.1\Files\private\10203636\security\trustroots\device\certificates\TMO_trusted_third_party_certificate.cer"

0.4.1 Change-Log:
- Improved: Shows warning messages raised from the RofsBuild.exe command
- Improved: ROFX Rebuild

0.4 Change-Log:
- New: FAT32 file-system is now supported. (X6 UDA is in FAT32 format)
- New: Extension Column in the grid. So you can easily remove unneeded languages files from the ROFS
- New: Experimental ROFx support... It should work but NEEDS TO BE TESTED!
- New: Automatically creates a Backup File when repacking firmware.
- Improved: FAT Detection
- Fixed: ROFS Rebuild for N97



*** Description ***

Nokia Cooker is a PC software reserved to the Cookers, which allows to modify the files containing the phone's firmware to create customized firmwares versions named Cooked-Firmware.
Nokia Cooker can modify data which is located in:
- UDA
- CORE (ROFS1 data only)
- ROFS
- ROFx

Not all the ROFS/ROFx can be modded!
Modding a protected ROFS/ROFx you'll risk to brick the phone.
If you aren't sure that your ROFS/ROFx can be modded, don't do it.
The modding of the UDA, instead, is always a safe operation.

This software is provided "as is" and moreover, WITHOUT any technical support, so, DO NOT contact me about this, because you WILL NOT receive any reply.

If you don't know how to install, or how to use it, probably you don't need Nokia Cooker at all.


