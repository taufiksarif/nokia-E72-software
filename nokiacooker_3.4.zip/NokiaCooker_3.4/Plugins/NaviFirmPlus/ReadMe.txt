
NaviFirm+ 2.5 - rewritten from scratch by Marco Bellino - based on EPICBIZNUS idea
http://www.symbian-toys.com/NaviFirm.aspx

NaviFirm+ full features are available to Donors only.
Make a Donation to get immediately a NaviFirm+ account.

Terms and Conditions:
your account (or even the whole service), could be suspended or terminated at any time, without prior notice and without refund.
By donating you accept these Terms.

Features Available to non-donors:
- Search latest firmware version by Product Code
- Download latest firmware version
- Add Product Codes to the Favourite List to be notified of new firmware releases

Additional Features Available to donors only:
- Notification of firmware changes since last login.
- Freely browse all the Firmware versions available for any device.
- Download / Copy to ClipBoard, any firmware version.
- Show hidden/replaced/removed variants


*** History ***
2.5 Change-Log:
- Improved: Welcome Message can now be scrolled
- Improved: minor GUI changes
- Fixed: crash when downloading a firmware which has been found through Nokia Care Suite and user is donor
- Fixed: the item "Upload New Product Codes" is now disabled properly
- Fixed: filters gets cleared when searching on Nokia Care Suite

2.4 Change-Log:
- New: Variants that (for any reason) have been replace/removed/hidden from Nokia Care Suite server, will be shown by NaviFirm+ in RED colour.
		You can change this behaviour by manually editing the Config_v2.xml file and set ShowHiddenVariants to False.
- Improved: Favourite list can now detect new Variants available for the same Product Code / Software Release (it can happen when a variant is replaced by Nokia with another)
- Improved: it is possible to donate using Credit Card or Skrill/MoneyBookers. These donations are accepted worldwide, also from counties not supported by PayPal.

2.3 Change-Log:
Non-donors will be happy to know that in this release, they can use some basic features of NaviFirm+ without needed to login ;)
These are the NaviFirm+ features available to Non-donors:
- insert a Product Code to check the latest available release in Nokia Care Suite server
- download the latest available release from Nokia Care Suite server
- add some Product Code to the Favourite list to be notified when a new software release is available in Nokia Care Suite server

- New: Search in Nokia Care Suite feature (available to non-donors too).
  You can now insert a Product Code in the textbox to search for it in Nokia Care Suite Server
  Non-donors that were using Nokia Care Suite Tool to search for new firmware versions, can totally replace it with NaviFirm+ ;)
- Improved: the Favourite Product Codes feature has been opened to the non-donors too.
- Improved: minor GUI changes
- Fixed: some issues in the auto-update features (delay for the app-restart was too short)

2.2 Change-Log:
- Improved: Favourite Product Codes are now saved on a different file MyProductCode.xml
- Improved: internal code refactoring for better maintenance
- Improved: minor GUI changes
- Fixed: unexpected crash when selecting the variant, while the cache was automatically cleared
- Fixed: sometimes users received the message "invalid username or password"
- Known Issues: doesn't support proxy. Proxy support will be added in next releases.

2.1 Change-Log:
- New: you can now report missing Product Code, by uploading a .txt list of product codes to the server, so the missing Product Codes will be added to the database. "Product Codes > Upload New Product Codes to NaviFirm+"
       the product codes listed in the .txt file should follow any of these formats:
	059T1S4:RM-892 VAR EURO GB O2 SL BLACK
	059S917:RM-892 VAR GB CV WHITE
	059S8H6   
    	059S8L8   
	RM-839 EURO_E5_YELLOW_CYRMAC_MK		059S125
	RM-839 EURO_E5_YELLOW_GREEK_GR		059S127
- Improved: Favourite Product Codes list has been limited to a maximum of 10 entries
- Improved: prevents running multiple NaviFirm+ instances
- Fixed: all the datetime fields are now saved as UTC format, fixing some cache handling issues.
- Known Issues: doesn't support proxy. Proxy support will be added in next releases.

2.0 Change-Log:
- New: NaviFirm+ automatically downloads and installs new updates
- New: Engine Rewritten from scratch
- New: Favourites Product Codes list
- Improved: trasfer speed! network communication is gzip-compressed
- Improved: caching policy is handled by the server, you don't need to worry about cleaning the cache to get fresh results
- Improved: refuses to add duplicated files to the download queue 
- Improved: minor GUI improvements
- Removed: ShowExtendedInfo and ServerIndex settings
- Known Issues: doesn't support proxy. Proxy support will be added in next releases.

1.7 Change-Log:
- New: Ported to .NET Framework 4.0
- New: Shows additional Product informations in the tooltip, including phone's image.
       Note that the tooltip is disabled by default, if you want to enable it, you must change the NaviFirmPlus.Config file in this way:
     <setting name="ShowTooltip" serializeAs="String">
        <value>True</value>
      </setting>

1.6 Change-Log:
- New: added notifications about the current connection status and the amount of trasferred bytes
- Improved: .vpl file is now handled without showing any window (you can disable the .vpl parsing changing the NaviFirmPlus.exe.config)
- Improved: better data transfer speed
- Improved: connection engine has been rewritten 
- Improved: minor changes to the status bar
- Fixed: crash when double-click on "Size" column
- Fixed: sorting on the "Size" column was not working proprerly

1.5 Change-Log:
- New: it is now possibile to Download up to 20 files simultaneously. You just need to increase the Download Sessions limit (default value is 2).
- New: added option to automatically append the PC to the destination path

1.4 Change-Log:
- New: the download manager has been rewritten from scratch. Using the new Download Queue you can enqueue all the fw files you need to download, while keeping to use NaviFirm+
- Improved: the Parse VPL checkbox has been removed, you can change this setting through the NaviFirmPlus.exe.config file

1.3 Change-Log:
- Fixed: Bad layout on Chinese System
- Improved: Minor GUI changes

1.2 Change-Log:
- Fixed: Error when downloading large files.
- New: Added filesize and filetype details.
- New: Parse VPL option, will automatically download and parse the VPL file and will select mandatory fw files.

1.1 Change-Log:
- New: Added support for Nokia Care Suite Server! This server contains additional fw files, like the Drive E: 16Gb file for N8.
- Improved: At startup will use the latest server choosen by the user.

1.0 Change-Log:
- Fixed: The connection to the Quality Assurance server wasn't working properly.

0.9 Change-Log:
- Fixed: Due to some old debug code I forgot, NaviFirm+ unexpectedly closed itself after the 20 December.

0.8 Change-Log:
- Fixed: Crash on Windows 7

0.7 Change-Log:
- Improved: From now on this software, available on Symbian-Toys.com website, will be named NaviFirm+ in order to distinguish it from other variants.
- Improved: Download window provides detailed informations about the downloads

0.6 Change-Log:
- New: Can be embedded as NokiaCooker's plugin

0.5 Change-Log:
- New: Added Caching. 
- New: Advanced Filter for Results.
- New: Copy URLs to ClipBoard. This feature can be used to download files using any extenal Download Manager you like.
- Improved: Columns can be resized
- Improved: Window can be resized

