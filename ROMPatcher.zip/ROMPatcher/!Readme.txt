                  ROMPatcher+ v3.1 by Il.Socio
       Complete Symbian^3 package by Max << Crazy | Doctor

                         ıllıllııllıllı
                            SIStore!



List of introduced changes:

* Byte Pair compressed RP+ drivers and main executables
* Belle icon style and inner graphics modification
* Removed RP+ autostart entry (refer to ReadMe for Cookers)
* Included ultimate patches collection working on Symbian Belle



Known off-target effects of several patches:

* Dev_null - wrecks Gallery on Anna and older, as well as Videos
  application on Belle and newer that lack MDS official update
* More Sound in Loudspeaker - reduces the volume in headphones
  on all firmware versions
* Unlock FileManager and/or Show RAM and ROM - disrupts Music
  player (it shows memory full error), Profiles settings (cannot
  find any ringtones), and .sis(x) installation (file corrupted
  error) on Belle Refresh and older



No pop-up patch by Jazzfusion:

* RomPatcherPlus.exe 0x00004c77 0a > aa
* RomPatcherPlus2.exe 0x00004cfb 0a > aa
Warning: this is for information purpose only!
Be aware it is a troublesome business in case you want to apply
this theory in practice: at some stage, you will have to delete
C:\system\data\RPPlus.dat to launch ROMPatcher again. Although
translating .r01 is an utterly safe operation.



Good to know:

ROMPatcher is an integral part of Delight Custom Firmware that
makes it possible to modify system applications on the Z drive,
which are present in the ROM area of phone memory.

ROM is a storage area for system applications that need direct
access to resources and functions of each other. ROM contents
can vary considerably between phone models, even within the same
platform.

SuperPage is a memory structure shared between the bootloader
and the kernel, used to transfer information between them. In
early models, the protection control cell (i.e. unforgettable
CapsOff) locates right there. In later versions, protection was
complicated, and the ability to disable it straightforwardly
disappeared.

DomainSrv is a modification that allows you to run selected
applications with system startup. Thankfully to it, we can also
activate ROMPatcher patches during boot. The latest version of
DomainSrv is ver.6 - it allows you to run ROMPatcher and up to
three more applications besides it.

List of changes:
10-Apr-2009 v.1: First version;
19-Apr-2009 v.2: Several bugs fixed;
28-Apr-2009 v.3: Some extra stuff added;
09-May-2009 v.4: Early compatibility with ROMPatcher;
12-May-2009 v.5: Full compatibility with ROMPatcher;
16-May-2009 v.6: Possibility to run up to three other
applications in addition to ROMPatcher.

Order of applications to be launched at system startup:
C:\sys\bin\Boot0.exe
Z:\sys\bin\DomainSrv.exe (original unmodified DomainSrv)
C:\sys\bin\Boot1.exe
C:\sys\bin\0RPAutoStart.exe (ROMPatcher+)
C:\sys\bin\Boot2.exe

BootCopy is a small application from the same author that reads
the list from E:\BootCopy.DAT and copies the files given in the
following format:
---
z:\sys\bin\installserver.exe > c:\installserver.exe
c:\private\10003a5b\calendar > c:\data\calendar
c:\private\101f401d\logdbu.dat > e:\others\logs.bak
# Don't delete this line
---

Unfortunately, it has limitations, such as the inability to
delete folders and files and create folders. After setting
DomainSrv, rename and move bootcopy.exe to C:\sys\bin\Boot1.exe,
create your own instruction file E:\BootCopy.DAT and restart the
phone. BootCopy usage example is backup of the necessary files
at startup: this method also allows you to copy the files
occupied by the system. Moreover, you can clone a different
program of your choice as Boot2.exe and put it in C:\sys\bin\ -
it will start when the phone is turning on.

For security reasons, it is not recommended to use the DomainSrv
modification from the phone memory (C drive) because, in the
event of any problems, Hard Reset will be necessary; thus, the
loss of all data from the phone will occur. It is best to keep
the modification on a removable memory card (F drive) so that in
case of problems, you can start the phone without the memory
card. In addition, please note that c2z / e2z patches should not
initiate with the system (i.e. they should not be added to
DomainSrv autostart) since it may prevent the phone from proper
startup.

As a bonus, there is ChangeMAC utility by wadowice for firmware
other than Delight.