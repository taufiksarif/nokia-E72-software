ROMPATCHER+ v3.1  BELLE FP2 Version
http://www.symbian-toys.com/RomPatcherPlus.aspx

In order to use it you have to:
1) find a way to put *.ldd files in c:\sys\bin\	 (eg. by using SmartManager or by flashing a cfw)
2) Install the LiteVersion (it is self-signed)

Since the LiteVersion is self-signed patches can't be started automatically.
To let the autostart work, you can try to follow the workaround below:
3) apply the InstallServer Patch v1.7
4) install again the LiteVersion
