
ROMPATCHER+ v3.1  BELLE FP2 Version
http://www.symbian-toys.com/RomPatcherPlus.aspx

CLEAN ROFS1:
 - If you're modding the ROFS1, then, before to proceed, I strongly suggest you to remove some dummy files from the original fw.
 - These files have been placed by Nokia in \sys\bin\ to prevent the hack:
	DrwSecServer_0x20024114.exe	* drweb
	ScanServ_0x20032D79.exe		* umu
	symc_AVQuarantine.exe		* norton
	TmInstall.exe			* trend mobile security
	TmUninstall.exe			* trend mobile security
	TmRtsHook.pxt			* trend mobile security
	RPPAuto.exe			* RP+
	RomPatcherPlus.exe		* RP+
	0RPAutoStart.exe		* RP+

HOW TO INTEGRATE RP+ IN THE ROFS:
 - BELLE FP2: To integrate properly RP+ in the ROFS you can mod this file \private\2000D75B\startup\0\noncriticalcmdlist_hw.rsc
 - The modded file must launch RPPAuto2.exe

FURTHER NOTES: 
 - Don't mess-up with RP+ files and filenames.
 - Don't place the RPPlus.dat file in the cooked fw for AutoStarting patches, it will not work!
 - If you want to distribuite additional patches, you don't need to use the scriptinit stuff, you can just add them to the \System\Data\RP_Patches.zip and RP+ will do the work for you.
 - If you follow those simple guidelines, you'll not notice any problems to integrate RP+ in your cooked fw ;)
