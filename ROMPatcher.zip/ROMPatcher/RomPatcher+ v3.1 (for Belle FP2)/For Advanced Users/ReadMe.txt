
ROMPATCHER+ v3.1  BELLE FP2
http://www.symbian-toys.com/RomPatcherPlus.aspx

Here's the DomainSrv.exe by wadowice.
It has been sligtly modded to launch RPPNotifier2.exe

You should already know what it is and how to install it.
If you never heard nothing about it then you're not an "Advanced User" yet and you should continue to ignore it, until you'll find out what's the DomainSrv.exe purpose :)
