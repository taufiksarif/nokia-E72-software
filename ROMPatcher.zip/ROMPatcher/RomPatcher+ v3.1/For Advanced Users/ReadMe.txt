
ROMPATCHER+ v3.1
http://www.symbian-toys.com/RomPatcherPlus.aspx

This is DomainSrv.exe by wadowice.
You should already know what it is and how to install it.
If you never heard nothing about it then you're not an "Advanced User" yet and you should continue to ignore it, until you'll find out what's the DomainSrv.exe purpose :)
