ROMPATCHER+ v3.1
http://www.symbian-toys.com/RomPatcherPlus.aspx


HOW TO INTEGRATE RP+ IN THE UDA:
 - use NaviFirm+ http://www.symbian-toys.com/NaviFirmPlus.aspx and download your original fw files.
 - use NokiaCooker http://www.symbian-toys.com/NokiaCooker.aspx to open the UDA fw file and place all the *.ldd files inside \sys\bin\ folder, eventually press the save button.
 - flash the fw files in your device using Phoenix or JAF.
 - install RomPatcherPlus_3.1_LiteVersion.sisx


FURTHER NOTES: 
 - The most important thing is to place *.ldd files inside the \sys\bin\ folder.
 - I've explained how to do it using a NaviFirm+ and NokiaCooker and it is a bit tricky, so if you know other easier ways do to place those files in \sys\bin\ then good for you! ;)
