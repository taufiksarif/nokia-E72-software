
ROMPATCHER+ v3.1
http://www.symbian-toys.com/RomPatcherPlus.aspx

HOW TO INTEGRATE RP+ IN THE ROFS:
 - 3rd / 5th: To integrate properly RP+ in the ROFS you only need to add a modded Starter*.rsc to the \Resource\
 - S^3: To integrate properly RP+ in the ROFS you can mod this file \private\2000D75B\startup\0\noncriticalcmdlist_hw.rsc
 - The modded file must launch RPPAuto.exe

FURTHER NOTES: 
 - Don't mess-up with RP+ files and filenames.
 - Don't place the RPPlus.dat file in the cooked fw for AutoStarting patches, it will not work!
 - If you want to distribuite additional patches, you don't need to use the scriptinit stuff, you can just add them to the \System\Data\RP_Patches.zip and RP+ will do the work for you.
 - If you follow those simple guidelines, you'll not notice any problems to integrate RP+ in your cooked fw ;)
