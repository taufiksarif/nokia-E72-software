

ROMPATCHER+ v3.1
http://www.symbian-toys.com/RomPatcherPlus.aspx


RomPatcher+ is an improved and fixed version of the RomPatcher software developed by ZoRn.
Using RomPatcher+ it is possibile to reach a new level of customization for you Symbian phone.

This is the list of the main differences in comparison with RomPatcher by ZoRn:
- New: compatibile with all the 3rh, 5th, S^3 devices
- New: support for compiled patches
- New: can dump the whole rom content to file \romdumpplus.dmp
- New: can dump the SuperPage content to file \superpage.dmp
- New: full support for DomainSrv.exe autostart, with Recovery Fault
- New: introduced new commands ord_rel, ord_snr which allow to patch DLL using ordinal
- New: can be integrated in cooked ROM firmware
- New: it is now possible to apply/remove patches with just 1 click.
- New: added vertical scrollbar.
- New: introduced the new command "+SuperPage" which allow to patch the RAM area where is stored the SuperPage.
- New: introduced support for a new commands, info: return: error: check the demo1-4.rmp patches included.
- New: introduced #ifdef, #ifndef, #else, #endif, #define statements. This will allow to retrieve system values at runtime to create more flexible and powerful patches. Check the ReadMe_Macros.txt for all the details.
- New: you can search / filter the patches in the list. Just start typing the patch name to apply the filter.
- New: wildcard ?? support for patches.
- Fixed: Kern-Exec0 error when closing RomPatcher after a patch was applied.
- Fixed: doesn't unexpectedly crash when using large and complex patches.
- Fixed: RP+ can correcly patch contiguous shadow ram pages without any crash.
- Improved: the "Patch Info..." option shows all the information lines contained in the patch.



*** How to install ***
There exists many ways to install RomPatcher+, here's a couple of them:
1) If your phone has been hacked to allow installation of unsigned .sis then install RomPatcherPlus_3.1.sis
2) If your phone has not been hacked yet, check out the file "LiteVersion\ReadMe.txt"



*** Change-Log v3.0 > v3.1 ***
+ New: Lite Version is already Signed, you don't need to sign it with a DevCert ;)
+ Improved: InstallServer.rmp patch has been updated
+ Improved: RomPatcherAuto.exe has been renamed to RPPAuto.exe for better compatibility with Samsumg Omnia autostart.
+ NOTE: Due to UID change, you have to uninstall any previous RP+ version before installing RP+ 3.1 (but you can keep the *.ldd files)



*** Other Important Stuff ***
Feel free to post RP+ v3.1 on forums or everywhere you like, I want just kindly ask you to include the warning message below which is important for the survivor of the project:

[quote]
Warning: If you like this software then support RP+ with a donation.
http://www.symbian-toys.com/rompatcherplus.aspx
[/quote]


Regards,
Marco.


Thanks to:
- ZoRn for the original RomPatcher idea.
- FCA00000 for its brilliant brain.
- wadowice, templove, bugb, abgnokia, leftup, CODeRUS, Leonapapa, PNHT, stas686 and others, for their contribution to the underground Symbian scene, keep up with the good job!
- megaexer for svg icon.
